package com.sena.ficha2758495backend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ficha2758495BackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(Ficha2758495BackendApplication.class, args);
	}

}
