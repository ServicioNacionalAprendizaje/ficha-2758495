package com.sena.ficha2758495backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ficha2758495BackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
